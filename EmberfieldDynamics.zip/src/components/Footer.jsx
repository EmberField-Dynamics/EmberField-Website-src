import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useLanguage } from '../context/LanguageContext'
import { useAdmin } from '../context/AdminContext'
import { useTheme } from '../context/ThemeContext'

export default function Footer() {
  const { lang } = useLanguage()
  const { projects } = useAdmin()
  const { theme } = useTheme()
  const [email, setEmail] = useState('')
  const [subscribed, setSubscribed] = useState(false)

  const p = (path) => `/${lang}${path}`
  const logoSrc = theme === 'dark' ? '/white-color-logo.png' : '/gray-color-logo.png'

  const handleSubscribe = (e) => {
    e.preventDefault()
    if (email) { setSubscribed(true); setEmail('') }
  }

  const linkHover = (e) => { e.currentTarget.style.color = '#10B981' }
  const linkLeave = (e) => { e.currentTarget.style.color = '#94A3B8' }

  const socialBtnStyle = {
    width: '42px', height: '42px', borderRadius: '10px',
    border: '1px solid rgba(255,255,255,.1)',
    background: 'rgba(255,255,255,.03)',
    backdropFilter: 'blur(12px)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    transition: 'all 0.25s', cursor: 'pointer',
  }

  return (
    <footer style={{ background: '#030712', color: '#94A3B8', position: 'relative', overflow: 'hidden' }}>
      <div style={{
        position: 'absolute', inset: 0,
        backgroundImage: "url('/worldmap.png')",
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        opacity: 0.06,
        pointerEvents: 'none',
      }}/>

      <div style={{
        position: 'absolute', inset: 0,
        backgroundImage: 'radial-gradient(circle, rgba(255,255,255,0.12) 1px, transparent 1px)',
        backgroundSize: '24px 24px',
        opacity: 0.3,
        pointerEvents: 'none',
      }}/>

      <div style={{ position: 'relative', zIndex: 1, maxWidth: '1200px', margin: '0 auto', padding: '80px 40px 0' }}>
        <div style={{
          background: 'rgba(16,185,129,0.06)',
          border: '1px solid rgba(16,185,129,0.15)',
          borderRadius: '16px', padding: '40px',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          flexWrap: 'wrap', gap: '24px', marginBottom: '64px',
        }}>
          <div>
            <h3 style={{ color: '#fff', fontSize: '20px', fontWeight: 700, marginBottom: '8px' }}>Stay Updated</h3>
            <p style={{ fontSize: '14px', color: '#94A3B8' }}>New services, infrastructure releases, and more.</p>
          </div>
          <form onSubmit={handleSubscribe} style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
            <input
              type="email" placeholder="Email Address" value={email} onChange={e => setEmail(e.target.value)}
              style={{
                padding: '12px 18px', borderRadius: '10px',
                border: '1px solid rgba(255,255,255,.1)', background: 'rgba(255,255,255,.05)',
                color: '#fff', fontSize: '14px', outline: 'none', width: '260px',
              }}
            />
            <button type="submit" style={{
              padding: '12px 24px', borderRadius: '10px', border: 'none',
              background: '#10B981', color: '#000', fontSize: '14px', fontWeight: 700,
              cursor: 'pointer', transition: 'all 0.25s',
            }}
              onMouseEnter={e => { e.currentTarget.style.boxShadow = '0 0 20px rgba(16,185,129,0.4)' }}
              onMouseLeave={e => { e.currentTarget.style.boxShadow = 'none' }}
            >{subscribed ? 'Subscribed!' : 'Subscribe'}</button>
          </form>
        </div>

        <div style={{
          display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 1fr',
          gap: '48px', marginBottom: '64px',
        }} className="footer-grid">

          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '20px' }}>
              <img src={logoSrc} alt="Logo" style={{ height: '32px', objectFit: 'contain' }}/>
              <span style={{ color: '#fff', fontSize: '16px', fontWeight: 700 }}>Emberfield Dynamics</span>
            </div>
            <p style={{ fontSize: '14px', lineHeight: 1.8, maxWidth: '380px', color: '#94A3B8' }}>
              Enterprise Minecraft, Discord and Infrastructure Solutions.
            </p>
          </div>

          <div>
            <div style={{ color: '#fff', fontSize: '12px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '2px', marginBottom: '20px' }}>Navigation</div>
            {[
              [p('/'), 'Home'],
              [p('/services'), 'Services'],
              [p('/developers'), 'Developers'],
              [p('/pricing'), 'Pricing'],
              [p('/contact'), 'Contact'],
            ].map(([to, label]) => (
              <Link key={to} to={to} style={{ display: 'block', fontSize: '13px', color: '#94A3B8', marginBottom: '10px', transition: 'color 0.2s' }}
                onMouseEnter={linkHover} onMouseLeave={linkLeave}>{label}</Link>
            ))}
          </div>

          <div>
            <div style={{ color: '#fff', fontSize: '12px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '2px', marginBottom: '20px' }}>Services</div>
            {['Minecraft Development', 'Discord Bots', 'Web Development', 'Infrastructure'].map((item) => (
              <Link key={item} to={p('/services')} style={{ display: 'block', fontSize: '13px', color: '#94A3B8', marginBottom: '10px', transition: 'color 0.2s' }}
                onMouseEnter={linkHover} onMouseLeave={linkLeave}>{item}</Link>
            ))}
          </div>

          <div>
            <div style={{ color: '#fff', fontSize: '12px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '2px', marginBottom: '20px' }}>Legal</div>
            {['Privacy Policy', 'Terms', 'Cookies'].map((item) => (
              <a key={item} href="#" style={{ display: 'block', fontSize: '13px', color: '#94A3B8', marginBottom: '10px', transition: 'color 0.2s' }}
                onMouseEnter={linkHover} onMouseLeave={linkLeave}>{item}</a>
            ))}
          </div>
        </div>

        <div style={{ borderTop: '1px solid rgba(255,255,255,.08)', paddingTop: '32px', paddingBottom: '32px' }}>
          <div style={{
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            flexWrap: 'wrap', gap: '24px',
          }} className="footer-bottom">
            <div>
              <div style={{ fontSize: '13px', color: '#6B7280' }}>&copy; 2026 Emberfield Dynamics</div>
              <div style={{ fontSize: '12px', color: '#4B5563', marginTop: '4px' }}>Built with passion for Minecraft communities and modern infrastructure.</div>
            </div>

            <div style={{ display: 'flex', gap: '10px' }}>
              <a href="#" style={socialBtnStyle}
                onMouseEnter={e => { e.currentTarget.style.borderColor = '#10B981'; e.currentTarget.style.boxShadow = '0 0 20px rgba(16,185,129,.3)'; e.currentTarget.style.transform = 'translateY(-2px)' }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = 'rgba(255,255,255,.1)'; e.currentTarget.style.boxShadow = 'none'; e.currentTarget.style.transform = 'none' }}>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="#94A3B8">
                  <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/>
                </svg>
              </a>
              <a href="#" style={socialBtnStyle}
                onMouseEnter={e => { e.currentTarget.style.borderColor = '#10B981'; e.currentTarget.style.boxShadow = '0 0 20px rgba(16,185,129,.3)'; e.currentTarget.style.transform = 'translateY(-2px)' }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = 'rgba(255,255,255,.1)'; e.currentTarget.style.boxShadow = 'none'; e.currentTarget.style.transform = 'none' }}>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="#94A3B8">
                  <path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0 0 24 12c0-6.63-5.37-12-12-12z"/>
                </svg>
              </a>
              <a href="#" style={socialBtnStyle}
                onMouseEnter={e => { e.currentTarget.style.borderColor = '#10B981'; e.currentTarget.style.boxShadow = '0 0 20px rgba(16,185,129,.3)'; e.currentTarget.style.transform = 'translateY(-2px)' }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = 'rgba(255,255,255,.1)'; e.currentTarget.style.boxShadow = 'none'; e.currentTarget.style.transform = 'none' }}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="#94A3B8">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                </svg>
              </a>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @media (max-width: 768px) {
          .footer-grid { grid-template-columns: 1fr 1fr !important; gap: 32px !important; }
          .footer-bottom { flex-direction: column !important; align-items: center !important; text-align: center !important; }
        }
        @media (max-width: 480px) {
          .footer-grid { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </footer>
  )
}
